import sys
import asyncio
import websockets
import threading
from PyQt6.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QWidget, QPushButton
from PyQt6.QtGui import QPixmap, QImage
from PyQt6.QtCore import QTimer, Qt
from PIL import ImageGrab, Image
import numpy as np
import base64
from io import BytesIO

class ScreenCaptureWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.recording_enabled = False

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.grab_screen)
        self.timer.start(30)  # 10 frames per second

        self.websocket = None
        threading.Thread(target=self.start_websocket).start()

    def initUI(self):
        self.setWindowTitle("Screen Capture Demo")
        self.setGeometry(100, 100, 800, 600)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout(self.central_widget)

        self.label = QLabel(self)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(self.label)

        self.record_button = QPushButton("Start Recording", self)
        self.record_button.clicked.connect(self.toggle_recording)
        self.layout.addWidget(self.record_button)

    def grab_screen(self):
        if self.recording_enabled:
            screenshot = ImageGrab.grab()
            buffered = BytesIO()
            screenshot.save(buffered, format="JPEG")
            screenshot_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
            asyncio.run_coroutine_threadsafe(self.send_frame(screenshot_base64), self.loop)

            # Update the frame on the sender's own display
            screenshot_qimage = QImage.fromData(base64.b64decode(screenshot_base64))
            self.update_frame(screenshot_qimage)

    async def send_frame(self, frame):
        if self.websocket:
            try:
                await self.websocket.send(frame)
                print("Frame sent")
            except websockets.ConnectionClosed:
                print("WebSocket connection closed")

    async def receive_frame(self):
        try:
            async for message in self.websocket:
                print("Frame received")
                screenshot_data = base64.b64decode(message)
                screenshot_qimage = QImage.fromData(screenshot_data)
                self.update_frame(screenshot_qimage)
        except websockets.ConnectionClosed:
            print("WebSocket connection closed")

    def update_frame(self, qimage):
        pixmap = QPixmap.fromImage(qimage)
        # размеры тут
        self.label.setPixmap(pixmap.scaled(900,1200, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        print("Frame updated on label")

    def toggle_recording(self):
        self.recording_enabled = not self.recording_enabled
        if self.recording_enabled:
            self.record_button.setText("Stop Recording")
        else:
            self.record_button.setText("Start Recording")

    def start_websocket(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self.connect_to_server())

    async def connect_to_server(self):
        uri = "ws://26.248.111.145:8766"
        async with websockets.connect(uri) as websocket:
            self.websocket = websocket
            print("Connected to server")
            await self.receive_frame()

def main():
    app = QApplication(sys.argv)
    mainWindow = ScreenCaptureWindow()
    mainWindow.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
